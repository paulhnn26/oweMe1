<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="h1 m-2 p-2">Rechnungen</h2>
                <div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="h2">Lege hier neue Rechnungen an</h2>
                                <form method="POST" action="<?php echo e(url('savepayment')); ?>" class="form-control">
                                    <?php echo csrf_field(); ?>
                                    <div class="md-3">
                                        <label class="form-label" >Wie viel wird dir geschuldet</label>
                                        <input type="text" class="form-control" name="amount" placeholder="Betrag eingeben">
                                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                                    </div>
                                    <div class="md-3 mt-2">
                                        <label class="form-label">Wer schuldet dir Geld</label>
                                        <select name="debtorName" >
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['debtorName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                    </div>
                                    <div class="md-3">
                                        <label class="form-label" >Nachricht</label>
                                        <input type="text" class="form-control" name="message" placeholder="Nachricht">  
                                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"> <?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>             
                                    </div>
                                    <button type="submit" class="btn btn-primary bg-primary mt-2">Erstellen</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="container pt-2 mt-4 mb-4">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"> <?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
                    <div class="search"> 
                        <h3 class="h3">Suche nach Rechnungen</h3>
                        <input type="search" name="search" id="search" placeholder="Suche" class="form-control">
                    </div>
                </div>
                	<table class="table table-striped table-bordered table-hover"> 
                        <thead>
                            <tr>   
                                <th>Erstellt</th>                           
                                <th>Wer schuldet dir </th>
                                <th>Nachricht </th>
                                <th>Betrag </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="Content">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payment->created_at); ?></td>
                                <td><?php echo e($payment->debtorName); ?></td>
                                <td><?php echo e($payment->message); ?></td>
                                <td><?php echo e($payment->amount); ?> €</td>                              
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(url('editpayment/'.$payment->id)); ?>">Bearbeiten</a>
                                    <a class="btn btn-danger" href="<?php echo e(url('deletepayment/'.$payment->id)); ?>">Löschen</a>
                                   </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>

            </div>
        </div>
    </div>
    <div class="container pt-2 mt-4">
        <h2 class="h2 m-2 p-2">Deine Schulden</h2>
        <div class="row">
        <div class="col-md-12">
        <table class="table table-striped table-dark"> 
            <thead>
                <tr>
                    <th>Erstellt </th>
                    <th>Du schuldest </th>
                    <th>Nachricht </th>
                    <th>Betrag </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $debtdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($payment->created_at); ?></td>
                    <td><?php echo e($payment->userName); ?></td>
                    <td><?php echo e($payment->message); ?></td>
                    <td><?php echo e($payment->amount); ?> €</td>
                    <td>
                        <a class="btn btn-success" href="<?php echo e(url('deletepayment/'.$payment->id)); ?>">Ich habe bezahlt</a>
                       </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         
        </table>
        
</div>
        </div>
    </div>
    <script type="text/javascript">
    $('#search').on('keyup', function(){

        $value =$(this).val();
        $.ajax({
            type:'get',
            url: '<?php echo e(URL::to('search')); ?>', 
            data:{'search':$value},
            success:function(data){
                $('#Content').html(data);
            }
        });
    })
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/paymentlist.blade.php ENDPATH**/ ?>