<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('success')): ?>
                <div class="alert"> <?php echo e(Session::get('success')); ?></div>
                <?php endif; ?>
                <h2 class="h2">Neue Rechnung</h2>
                <form method="POST" action="<?php echo e(url('savepayment')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="md-3">
                        <label class="form-label" > amount</label>
                        <input type="text" class="form-control" name="amount" placeholder="Betrag eingeben">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"> <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="md-3">
                        <label class="form-label">debtorName</label>
                        <select name="debtorName" >
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>
                    <div class="md-3">
                        <label class="form-label" > message</label>
                        <input type="text" class="form-control" name="message" placeholder="Nachricht">

                    </div>
                    <div class="md-3">
                        <label class="form-label" > debtorID</label>
                        <input type="text" class="form-control" name="debtorID" placeholder="Wer soll zahlen">
                    </div>
                    <button type="submit" class="btn btn-primary"> Erstellen</button>
                    <a href="<?php echo e(url('paymentlist')); ?>" class="btn btn-danger"> Back</a>
                </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/addpayment.blade.php ENDPATH**/ ?>